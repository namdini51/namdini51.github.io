---
name: PlaceHolder Project
tools: [nothing, important]
image: https://www.sketchappsources.com/resources/source-image/project-neon-groove-music-ui.png
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
external_url: https://www.google.com
---